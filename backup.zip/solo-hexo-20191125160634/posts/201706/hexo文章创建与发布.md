title: hexo文章创建与发布
date: '2017-06-02 18:30:38'
updated: '2017-06-02 18:30:38'
tags: [hexomarkdown]
permalink: /articles/2017/06/02/1572681386467.html
---
## 简述
网上已经有许许多多的有关hexo+github搭建博客的文章了，hexo博客的优点也不用我再去赘述了；我也就不打算板门弄斧，再写一篇文章了。

这里主要是归纳整理一些相关博文，并且整理一下文章的书写和发布流程，避免长时间不写博文，忘记流程然后去翻别人的博客的迷之尴尬。
<!--more-->

## hexo博客搭建教程
[搭建教程链接](http://opiece.me/2015/04/09/hexo-guide/)

[NexT主题指南](http://theme-next.iissnan.com/getting-started.html)

[写文章的markdown语法](http://www.yaosansi.com/post/markdown-on-github/#1-_基本写作)

[表情包](https://www.webpagefx.com/tools/emoji-cheat-sheet/)

[相关链接](https://segmentfault.com/a/1190000009478837)

[报错解决方法](http://www.jianshu.com/p/465830080ea9)
## 流程
1. 在hexo文件夹下用Git Bash执行命令：`$ hexo new "my massage"`
2. 在`E:\hexo\source\_post`（假如你的hexo是放在E盘下的话）中打开my-massage.md,打开方式建议用notepad++。
3. 用markdown语法写完后执行`$ hexo g`生成静态文件。
4. 然后执行`$ hexo s`在本地预览效果；**（敲黑板，划重点）**这里如果效果不好，执行了下一步也不要紧，可以在nodepad++中更改然后重新发布。
5. 然后执行`$ hexo d`同步到github
6. 最后就可以在[你的博客](https://lsdm.github.io/)上访问了。