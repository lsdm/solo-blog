title: WEB语义化和W3C标准初探
date: '2017-09-10 06:57:28'
updated: '2017-09-10 06:57:28'
tags: [w3c]
permalink: /articles/2017/09/10/1572665597469.html
---
## W3C标准包括定义
w3c(World Wide Web Consortium)标准：是一些列web标准的集合，在百度上面搜索也只是告诉你w3c标准主要对应几个方面：
1.结构化标准语言(xml,xhtml)
2.表现标准语言(css)
3.行为标准(dom,ecmascript)
4.其他标准，包括字体，安全，语义化很多方面的内容。
<!--more-->
>W3C standards define an Open Web Platform for application development that has the unprecedented potential to enable developers to build rich interactive experiences, powered by vast data stores, that are available on any device. Although the boundaries of the platform continue to evolve, industry leaders speak nearly in unison about how HTML5 will be the cornerstone for this platform. But the full strength of the platform relies on many more technologies that W3C and its partners are creating, including CSS, SVG, WOFF, the Semantic Web stack, XML, and a variety of APIs.

## [具体体现](https://segmentfault.com/a/1190000008516458)
目前为止w3c标准主要分为web结构、web设备、web设计与应用、web语义化、xml技术、web服务以及浏览和创作工具7大部分。每一个部分又细分为很多小部分，如下图所示：
### web设计和应用程序
这部分主要是涉及到web构建和web页面渲染的一些标准, 包括html,css,svg,ajax和其他的一些web应用程序。同时也涉及到web的可访问性方面的内容。
### web设备
这里主要讲互联网的应该无论何时何地都能够让任何设备访问。这包括移动电话和其他移动设备的网络访问，以及在消费电子，打印机，交互式电视，甚至汽车网络技术的使用。
### web结构
web的体系结构侧重于web基础技术和维持网络的一些原则。包括uri和http。
### web语义化
web语义化技术使人们根据相应的规则创建词汇表，编写数据处理规则，让计算机能够做更多有用的工作。
### xml技术
xml技术包括xml，xml命名空间，xml schema, xslt, exi 和其他相关的标准。它是可以定义其它语言的语言，最初设计主要是弥补html设计上的不足以强大的扩展性满足网络信息发布的需要，后来逐渐用于网络数据的转换和描述。设计的初衷是为了传输和存储语言，可以用户自定义标签。
### web服务
这部分的标准里面主要又定义了支付，安全和国际化方面的一些标准。
### 浏览和创作工具
主要介绍了人可以浏览器，媒体播放器访问web，并获取相关的咨询，也可以通过博客，cms系统，社交媒体发布信息到网上。
## 常用web标准
到目前为止w3c官网总共有92个标准(细分后的)，想具体了解请访问[链接](https://www.w3.org/TR/)，按照2/8原则，常用的有10多条，分别是：
1.web可访问性
2.视频
3.html
4.css
5.dom
6.xml
7.图形
8.语义化web
9.http
10.国际化
11.JavaScript apis
12.web安全
13.web字体
14.svg
15.音频
16.web性能
17.xhtml

## 什么是web语义化
>语义的概念： 可以简单地看作是数据所对应的现实世界中的事物所代表的概念的含义，以及这些含义之间的关系，是数据在某个领域上的解释和逻辑表示。---百度百科

**web语义化**： 对于HTML体系而言，Web语义化是指使用语义恰当的标签，使页面有良好的结构，页面元素有含义，能够让人和机器都容易理解。对CSS体系而言，

## web语义化具体体现
1.合理使用语义元素构建具有良好结构的页面；比如用hx标签组来表示不同的标题，用strong标签来表示强调。
2.合理使用CSS的class和id对元素进行修饰；比如left-bar，red-text等都有利于增强标签的语义。

## web语义化的好处
1.去掉或样式丢失的时候能让页面呈现清晰的结构：
2.屏幕阅读器（如果访客有视障）会完全根据你的标记来“读”你的网页
3.PDA、手机等设备可能无法像pc端的浏览器一样来渲染网页（通常它们对CSS的支持较弱）.
4.搜索引擎的爬虫也依赖于标记来确定上下文和各个关键字的权重.你的页面是否对爬虫容易理解非常重要,因为爬虫很大程度上会忽略用于表现的标记,而只注重语义标记.
5.减少开发中的差异化，便于团队开发和维护.