title: CSS3新功能属性
date: '2017-09-10 18:45:10'
updated: '2017-09-10 18:45:10'
tags: [CSS3]
permalink: /articles/2017/09/10/1572681387569.html
---
**tip1:无特别说明，所有CSS3属性都要加前缀**

### CSS3边框：
border-color受制于浏览器兼容，在项目中很少使用该属性；

border-image浏览器的支持度强一点，但也用的比较少；

border-radius支持较好
用途：可以制作圆角按钮；渐变的tabs效果；（IE低版本不支持）
<!--more-->
注意事项：
   如果要重置元素没有圆角，取值none没有效果，需取值为0；
   而且不同浏览器对派生子属性的写法还不一致；因此一般都使用标准语法。
   对于图片，表格的应用坑比较多。

box-shadow的使用也非常多。

### 图片背景：
background-color（背景颜色 ）

background-image（背景图片）

background-repeat（背景图片展示方式）

background-attachment（背景图片是固定还是滚动）

background-position（背景图片位置）

background-origin（指定绘制背景图片的起点）【IE9+等】

background-clip（指定背景图片的显示范围）

background-size（指定背景图片的尺寸大小）【IE9+等】

background-break（指定内联元素的背景图片平铺时的循环方式）【仅Firefox】

### CSS3文本：
从功能上可以分为三大类：字体，颜色，文本
#### 字体：
1.font-family
2.font-style
3.font-weight
4.font-stretch
5.font-variant
6.font-size-adjust
#### 文本：
1.word-spacing
2.letter-spacing
3.vertical-align
4.text-decoration
5.text-indent
6.text-align
7.line-height
8.text-transform
9.text-shadow【IE9+等；低版本使用滤镜代替】
10.white-space【IE6+等支持，取不同值支持版本不同；】
11.direction
12.text-overflow【IE6+等支持，取不同值支持版本不同；用于解决内容溢出；要在一定高度配合overflow：hidden和white-space：nowarp使用才能生效】
13.word-warp【IE6+等支持良好】
14.word-break【IE6+等支持，取不同值支持版本不同；】
#### 颜色
1.color

### CSS3透明
#### opacity属性：
alphavalue（0【透明不可见】-1【不透明可见】）|inherit【IE8+等支持，低版本使用滤镜】

### 盒模型：
box-sizing属性：content-box | border-box | inherit【IE8+等支持】
overflow-x/y属性：指定溢出内容的剪裁；【IE6+等支持】
resize属性：用于拖动改变元素大小；【IE不支持】
outline属性：用于突出元素，不占用空间；
**伸缩盒模型**     
多列布局：浏览器兼容性较差    
### 渐变效果：
【IE10+有效；IE9-通过滤镜来实现直线渐变】
线性渐变：
径向渐变：    
渐变兼容：
### 变形效果：
1.2D变形：IE9+等浏览器支持；
2.3D变形：IE10+等浏览器支持；

transform属性：transform：none | <transform-function> [<transform-function>]
transform-origin属性改变元素的原点【IE9+等浏览器支持； 】
transform-style属性指定嵌套元素在3D空间中如何呈现；
perspective属性可以简单的理解为视距；
perspective-origin属性主要用于决定perspective属性的源点角度；
backface-visibility属性决定元素旋转时背面是否可见；

### 过渡效果：
IE10+等浏览器支持；【设置起始效果；设置过渡属性；设置终止效果】

transition：transition-property transition-duration transition-timing-function transition-delay

### 动画效果：
IE10+等浏览器支持；【使用关键帧声明一个动画；在animation调用该动画】

animation：animation-name | animation-duration | animation-timing-function | animation-delay | animation-iteration-count | animation-direction |    animation-play-state | animation-fill-mode

### 媒体查询：
除IE8-外的浏览器都支持；
@media （媒体类型）and（媒体特性）{你的样式}
### 响应式布局：
让网页在不同的设备中展现不同的设计风格；
（弹性网格布局，弹性图片，媒体和媒体查询）；
三个条件【建立灵活的网格基础；图片可伸缩；不同的显示风格】
### web字体嵌入：
支持良好；使用@font-face引入上传到服务器的字体文件；