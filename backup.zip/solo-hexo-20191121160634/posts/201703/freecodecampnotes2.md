title: freecodecamp-notes-2
date: '2017-03-25 04:12:51'
updated: '2017-03-25 04:12:51'
tags: [blog]
permalink: /articles/2017/03/25/1572681388626.html
---
## 标签
span标签可以用于建立行内元素。

## 样式
影响HTML元素布局的有三个重要属性：
padding，border，margin；分别是内边距，边框，外边距。
padding控制元素content与元素border间距；margin控制border与元素实际所占空间距离，若为负值，元素会变大。
CSS 允许你使用padding-top、padding-right、padding-bottom 和 padding-left分别来自定义控制元素上右下左四个方向的 padding；也可以集中起来指定它们，如padding: 10px 20px 10px 20px，这四个值以顺时针方式排列：顶部、右侧、底部、左侧，简称：上右下左；margin同理。
<!--more-->
每个HTML页面有一个body元素，它的子元素可以继承其样式；浏览器读取css的顺序是从上到下的，同类样式发生冲突时，它会使用最后的声明；！important优先级(例：color:pink !important;)>行内样式>ID选择器>类选择器。

颜色值除了用英文表达，还可以用16进制数(#xxxxxx；#xxx；0-f)表示，以及rgb（x,x,x)（0-255）表示。

bootstrap是流行的css响应式框架；通过响应式设计，你无需再为你的网页设计一个手机版的，它可以实现自适应；Bootstrap使用响应式栅格系统，这使得把元素放入行内并为每个元素指定宽度变得很容易。

Font Awesome是一个很方便的图标库。

清理代码可以让页面看起来更简洁。

## 其他

感悟：
freecodecamp好是好，但是太细化了，还得回头了解一些没有提到的细节，比如bootstrap的使用。</br>
没有图的blog不是好blog。</br>
<img src="http://p1.bpimg.com/4851/4001143c71b75b0e.jpg"/>