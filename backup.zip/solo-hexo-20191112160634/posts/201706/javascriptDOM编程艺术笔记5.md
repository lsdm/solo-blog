title: javascript DOM 编程艺术笔记5
date: '2017-06-07 06:36:10'
updated: '2017-06-07 06:36:10'
tags: [javascript]
permalink: /articles/2017/06/07/1572681384435.html
---
## 第九章 第十章
### 网页组成
* 结构层由标记语言创建；主要展现网页的结构；
* 表现层由css完成，主要描述页面内容该如何呈现；
* 行为层展现了内容该如何响应事件。
网页是由结构层，表现层，行为层三者构成的共同体：网页中总是会有默认的表现和行为；这三者之间存在交叉重叠现象。
<!--more-->
### style属性
* 文档的元素节点有一个style属性（也是一个对象）；它包含着元素的样式。
* 在应用style属性时；对类似font-family的属性要转换成驼峰形式fontFamily。
* DOM中样式属性的单位和css的单位可能不同。（比如颜色值）

#### style属性局限性
只能返回内嵌样式；这将会导致结构与表现混杂。来自外部文件和内部的样式不能用style检索出来。但用DOM设置的样式可以用DOM再将它们检索出来。

Style是可读写的：`element.style.property = “value”;`(“”不能掉，否则value会被解释为变量)

### 何时使用DOM设置样式
#### 使用css的情况
* 为标签元素统一声明；
* 为特定的class属性元素统一声明；
* 为有独一无二的id属性的元素单独声明样式。
1. 根据元素在节点树里的位置来设置样式。（DOM在查询某位置元素上有优势）
2. 根据某种条件反复设置某种样式。（比如为了提高表格行的可读性而交替改变其背景色的斑马线效果）（特别是定时重复一组操作；css基本不可能实现。）
3. 针对类似css的：hover和DOM的onmouseover事件；一般选择最容易实现的方法。（浏览器一般对某些css支持不够好，但对DOM却很好；因此还要考虑浏览器对那种方法更支持）

在行为层里更改样式；更好地方法是直接改变元素的className属性。（使用setAttribute方法）不足在于其会替换（而非追加）该元素原有的class设置；（追加操作：`elem.className += “new className”`；之前需要判断原来是否有className属性。）

### setTimeout函数
Javascript函数setTimeout能够让某个函数在经过一定的时间后才开始执行。
`action = setTimeout(“function”,interval);`
在interval时间段内可以用clearTimeout(action);取消执行。
### 注意内容可访问性
W3C在Web内容可访问性指南里给出了这样的建议：除非浏览器允许用户冻结移动的内容，否则应该避免让内容在页面中移动。