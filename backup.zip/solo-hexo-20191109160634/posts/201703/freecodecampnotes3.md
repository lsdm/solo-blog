title: freecodecamp-notes-3
date: '2017-03-25 04:20:44'
updated: '2017-03-25 04:20:44'
tags: [blog]
permalink: /articles/2017/03/25/1572681382821.html
---
在学习jQuery时，用到了选择器来找到元素，运用方法。</br>
所有jQuery方法都是由$开始的，通常称作为 美元符号，或者简称为bling.</br>
    $(document).ready(function() {方法放置处});
jQuery通过选择器来选择一个元素的，然后操作元素做些改变；包括元素，类，id选择器。</br>
<!--more-->
用jQuery的.addClass()方法，就可以给元素加class；也可以通过jQueryremoveClass()方法去掉元素上的class。</br>
jQuery有一个叫做.css("属性","值")的方法能让你改变元素的CSS样式。
jQuery有一个.prop("属性",值)的方法让你来调整元素的属性。</br>
jQuery的.html()方法可以添加HTML标签和文字到元素，而元素之前的内容都会被方法的内容所替换掉;jQuery 还有一个类似的方法叫.text()，它只能改变文本但不能修改标记。</br>
jQuery有一个appendTo()方法可以把选中的元素加到其他元素中。
jQuery的clone()方法可以拷贝元素。
两个jQuery方法合在一起使用就叫方法链function chaining，这样使用起来很方便；例：
    $("#target5").clone().appendTo("#left-well")。
jQuery有一个方法叫parent()，它允许你访问指定元素的父元素；jQuery有一个方法叫children()，它允许你访问指定元素的子元素。
不能使用ID选择器时，jQuery允许用CSS选择器来选取元素，target:nth-child(n) CSS选择器允许你按照索引顺序(从1开始)选择目标元素的所有子元素。</br>
让整个body都有淡出效果(fadeOut)： $("body").addClass("animated fadeOut");



#其他
jquery确实强大，很多变化都可以在短代码内完成，只需要得到元素的ID即可。

[小黄人专属]<img src="http://p1.bpimg.com/4851/fb02cea296608e95.jpg">