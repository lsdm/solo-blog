title: javascript DOM 编程艺术笔记2
date: '2017-06-06 00:12:11'
updated: '2017-06-06 00:12:11'
tags: [javascript]
permalink: /articles/2017/06/06/1572681383299.html
---
## 第四章
### 重点
* 如何利用DOM提供的方法编写图片库脚本。
* 如何利用事件处理函数将javascript代码与网页集成在一起。

### 在javascript中改变元素属性
* 非DOM解决方案：`element.value = "the new value"`
* DOM解决方案:`element.setAttribute("value","the new value");`
<!--more-->
setAttribute是DOM Level1的组成部分，用（element.value=”the new value”）可以实现相同的效果；但DOM1的优势在于其可以修改文档中任意一个元素的任意属性，而且可移植性更好；DOM是一种适用于多种环境和多种程序语言的通用型API。
### 事件处理函数
事件处理函数可以在特定事件发生时调用特定的javascript代码。

添加事件处理函数的语法：event = “javascript statement(s)”;具体如onclick = “showPic（this）”。使用onclick时
，函数参数通常可以用this代替该元素。
#### 工作机制
一旦事件发生，相应代码就会得到执行，被调用的javascript代码可以返回一个值，这个值将传递给事件处理函数。

#### 常见事件
* `onclick` 当用户点击鼠标时；
* `onmouseover`鼠标移动到元素上时；
* `ommouseout` 鼠标移出元素时；
* `onchange` 输入字段被改变时；
* `onsubmit` 当提交 HTML 表单时；
* `onblur` 元素失去焦点时触发 
* `onchange` 该事件在表单元素的内容改变时触发( < input >, < keygen >, < select >, 和 < textarea >) 
* `onfocus` 元素获取焦点时触发 

* `onkeydown` 某个键盘按键被按下。
* `onkeyup` 某个键盘按键被松开。 
* `onkeypress` 某个键盘按键被按下并松开。
  
* `onunload` 用户退出页面。
* `onload` 当网页已加载时；当图像已加载时；
* `onresize` 窗口或框架被重新调整大小。 
* `onscroll` 当文档被滚动时发生的事件。
* `onbeforeunload` 在即将离开页面（刷新或关闭）时触发 

#### 注意
**`window.onload = func`；因为是在页面加载时调用某一函数，而非将函数值传给该事件，所以千万不能加().**
#### 性能改善1
若一个站点用到了多个javascript文件，为了减少对站点的请求次数，提高性能，应该将它们合并到一个文件中。

### childNodes属性
Element.childNodes可以用来获取任何一个元素的所有子元素，其是一个子元素数组。
文档里几乎每一样东西都是一个节点，甚至连空格和换行符都会被解释为节点而包含在childNodes属性所返回的数组中。
### nodeType属性
`node.nodeType`的值（数字）反映了节点类型，总共有12种，但仅其中三种具有实用价值。
元素节点为1，属性节点为2，文本节点为3。
### nodeValue属性
要改变一个文本节点的值，可使用DOM提供的nodeValue属性。`node.nodeValue`（注意：p元素本身的nodeValue属性是一个空值；而其文本是p元素的第一个子节点，因此应对其第一子节点调用nodeValue。）
### Node.firstChild与node.lastChild属性
`node.firstChild`与数组元素第一子元素`node.childNodes[0]`相同。
`node.lastChild`与数组元素最后一个子元素`node.childNodes[node.childNodes.length-1]`相同。