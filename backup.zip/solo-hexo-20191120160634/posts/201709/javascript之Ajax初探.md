title: javascript之Ajax初探
date: '2017-09-10 22:42:50'
updated: '2017-09-10 22:42:50'
tags: [javascript]
permalink: /articles/2017/09/10/1572681389415.html
---
## Ajax：Asynchronous javascript + XML；
### 优点：
能够向服务器请求额外的数据而无须卸载页面；
### 核心：
XMLHttpRequest对象（IE5和6中是ActiveXObject对象）；
<!--more-->
### XHR对象的属性包括：
responseText：作为响应主体被返回的文本。
responseXML：保存包含着响应数据的XML DOM文档。
status：响应的HTTP状态。
statusText：HTTP状态的说明。
### 步骤：
1.创建
2.启动
3.发送
4.接收响应

1.创建：对IE7+及其他浏览器；var XHR = new XMLHttpRequest()。[IE6要写兼容]
2.启动：XHR.open(type，URL，isSyn) ；
type表示发送的请求类型；一般是"get"或"post"；

GET请求：最常见；常用于向服务器查询某些信息。使用时可能会因为查询字符串的格式有问题发生错误；使用addURLParam函数可以确保查询字符串的格式良好并可靠的用于XHR对象。相比POST，消耗资源少，请求速度快。

POST请求：常用于向服务器发送应该被保存的数据。POST请求应该将数据作为请求的主体提交；可以包含非常多且格式不限的数据。可以使用XHR来模仿表单提交。

URL相对于执行代码的当前页面或使用绝对路径；调用该方法只是启动一个请求以备发送。

isSyn是boolean值，代表是否异步。

3.发送：XHR.send(null)；参数为请求主体，若无，一定要设置为null。
4.收到响应，检查status属性：当HTTP代码为200时说明响应成功返回；此时，responseText属性已就绪；在内容类型正确的情况下，responseXML也可以访问了。若状态为304，表示请求的资源没有被修改，可直接使用浏览器中缓存的版本，同时也意味着响应有效。
无论响应内容是什么，响应主体的内容都会保存到reaponseText属性中；对非XML数据，responseXML为null。
以上仅针对发送同步请求，要发送异步请求，可以检测XHR对象的readyStatus属性，它表示请求/响应过程的当前活动阶段。可取值如下：
0：未初始化，尚未调用open()方法；
1：启动。已调用open();未调用send()。
2：发送。已调用send();未收到响应。
3：接收。接收到部分响应数据。
4：完成。接收到全部响应数据。
其值每变化一次，都会触发一次readystatuschange事件。在调用open之前指定onreadystatechange事件处理程序才能保证跨浏览器的兼容性。另外，在接收到响应之前还可以调用abort()方法来取消异步请求；如：xhr.abort();
```
      XHR.onreadystatuschange = function(){
          if(XHR.readyState == 4){
               if((XHR.status >= 200 && XHR.status < 300) || XHR.status == 304){
                    alert(XHR.responseText)；
               }else{
                    alert("Request was unsuccessful:" + XHR.status);
               }
          }
     };
```
## HTTP头部信息
默认发送的头部信息包括一些基本的信息，还可以设置自定义的请求头部信息。使用setResponseHeader()方法接受两个参数，头部字段的名称和头部字段的值。要成功发送请求头部信息，必须在调用open方法后，send方法前调用该方法。

调用getAllResponseHeaders()方法则可以取得一个包含所有头部信息的长字符串。

## 跨域资源共享
通过XHR实现Ajax通信的一个主要限制来源于跨域安全策略，默认XHR对象只能访问与包含它的页面位于同一个域中的资源；但在实现安全的同时还有合理跨域请求的需要。//CORS技术

### 其他跨域技术
#### 图像Ping：
使用<img>标签；一个网页可以从任何网页中加载图像。该方法的得不到任何具体数据，但通过侦听load和error事件，它能知道响应是什么时候接受到的。主要缺点是只能发送GET请求，无法访问服务器的响应文本。
#### JSONP：
是JSON with padding的简写，是应用JSON的一种新方法；不过是包含在函数调用中的JSON。它由回调函数和数据组成；回调函数时当响应到来时应该在页面中调用的函数，其名字一般再请求中指定；而数据就是传入回调函数中的JSON数据。
优点是能够直接访问响应文本，支持浏览器与服务器间的双向通信。缺点是若其他域不安全可能会夹带一些恶意代码；且要确定JSONP请求是否失败并不容易。
#### Comet：
是一种服务器向页面推送数据的技术，能够实现实时推送，因此非常适合处理体育比赛和股票报价。

两种实现方式；长轮询---即浏览器定时向服务器发送请求。HTTP流---浏览器发送一个请求后，服务器以打开状态周期性的向浏览器发送数据。

服务器发送事件；是一种API，用于创建到服务器的单向连接，服务器通过它能发生任意数量的数据。支持长短轮询，HTTP流，且能在断开连接时自动确定何时从新连接。（IE不支持）
#### Web Sockets；
其目标是在一个单独的持久连接上提供双全工，双向通信。在javascript中建立之后，将一个HTTP请求发送到浏览器以发起连接，取得响应后建立的连接会由HTTP协议交换为Web Socket协议。

优点是能够在客户端与服务器间发送非常少量的数据同时减小开销；缺点是事件长，可能有安全隐患。
## 安全
为确保XHR访问的URL安全，通行的做法是验证发送请求者是否有权访问相应的资源。