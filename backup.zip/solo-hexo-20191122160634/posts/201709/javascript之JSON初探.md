title: javascript之JSON初探
date: '2017-09-10 22:42:25'
updated: '2017-09-10 22:42:25'
tags: [javascript]
permalink: /articles/2017/09/10/1572681384898.html
---
## JSON语法
javascript Object Notation：javascript对象表示法的简称就是JSON；相比XML，它是在javascript中读写结构化数据的更好方式。

JSON只是一种数据格式，但其并不从属于javascript。
JSON语法可以表示以下三种类型值：简单值（string，number，boolean，null但不包含undefined）；对象（键值对中的值可以是简单值，也可以是复杂数据类型的值）；数组（值可以是简单值，对象，数组）【不支持变量，函数或对象实例】
<!--more-->
相比javascript中的字符串，JSON字符串必须使用双引号。
相比javascript中的对象，JSON对象的属性必须加双引号（没有声明变量，没有末尾分号，也就是只有主体 ）。
相比javascript中的数组，JSON对象没有声明变量，没有末尾分号；也就是只有主体。

## 解析与序列化
### 为什么？：
数据在B/S之间是以字符串的形式传递的，与javascript方便可用的数据形式还是有差距，因此需要解析过程方便调用，同样，也需要序列化的过程方便传输。

以前通常用eval()函数解析,解释并返回javascript对象和数组，但由于存在执行恶意代码的风险，ES5就推出了JSON全局对象（IE8+,Firefox3.5+，Safari4+，Chrome，Opera10.5+支持；不支持的可以使用shim）对JSON解析的行为进行规范。

### 全局对象JSON：
stringify()用于将javascript对象序列化为JSON字符串；该字符串不包含任何空格或缩进。
序列化时所有函数和原型成员以及值为undefined的属性都会被有意忽略。
序列化选项：可以通过stringify(object，过滤器，选项)的两个参数实现过滤和保留缩进（在结果中插入了换行符提高了可读性；缩进字符串最长不能超过十个字符）；tringify不能满足某些对象自定义序列化的需求，而toJSON方法用于返回其自身的JSON数据格式。
序列化的顺序很重要。有效toJSON()方法>过滤器...

parse()用于将JSON字符串解析为原生javascript值。
解析时若传入的不是有效的JSON ，该方法会抛出错误。
解析对象；JSON.parse(json字符串，还原函数)