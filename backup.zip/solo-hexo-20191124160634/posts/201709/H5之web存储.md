title: H5之web存储
date: '2017-09-10 18:42:43'
updated: '2017-09-10 18:42:43'
tags: [H5]
permalink: /articles/2017/09/10/1572681387844.html
---
## 客户端存储：
通过浏览器提供的API将数据存储到用户的电脑上；

客户端存储遵循同源策略；不同站点无法相互读取对方存储的数据；同一站点不同页面之间共享存储数据。

形式：web存储；cookie；离线web应用......（都不安全）
<!--more-->
### web存储：
包括localStorage和sessionStorage对象【持久化关联数组；名值对的映射表】【支持大容量（5M）数据存储同时兼容所有现代主流浏览器】
1.localStorage与sessionStorage的区别：存储的有效期和作用域不同；
2.localStorage存储的数据是永久性的，除非应用刻意删除或通过设置浏览器配置删除，否则一直保存，永不过期；作用域限定在文档源（通过协议，主机名，端口来确定）级别，同源文档共享数据；
3.sessionStorage和存储数据的脚本所在的最顶层窗口或是浏览器标签页一致，一般窗口关闭就删除数据；作用域限定在文档源中，而且还被限制在顶级窗口中，同源不同窗口无法共享数据；
#### 使用：
A 通常被当作普通的javascript对象使用，通过设置属性存储字符串值，查询该属性来读取该值；
B 调用setItem()方法传入名，值实现数据存储；调用getItem()方法传入名字获取对应值；调用removeItem()方法（delete操作符IE8不支持）传入名字删除对应的数据；调用clear()方法可以删除所有的数据；使用length属性和key()方法传入0~length-1的数字，可以枚举所有存储数据的名字。

### cookie：
【javascript的API操作繁琐；只适合存储少量的文本数据；每次的http请求都会将这些数据传输到服务器端；所有浏览器都支持】
1.默认有效期很短，只能持续在web浏览器会话期间，要想延长有效期可以设置max-age属性；作用域通过文档源和文档路径来确定，该作用域通过cookie的path和domain属性配置，对创建它的页面和给页面同目录或子目录的其他页面可见。
2.使用前确保cookie启用：检测navigation.cookieEnabled为true；不支持的浏览器必须通过尝试读写和删除数据进行测试。
3,保存cookie：设置默认有效期的cookie值；只需将cookie属性设置为一个字符串形式的值：document.cookie = “name=”+ encodeURLComponent(value)；【使用encodeURLComponent函数是因为cookie中的值是不允许包含分号，逗号和空白符的；因此要对value进行编码】
4.读取cookie：先用split()方法分离；然后解码还原值；然后使用JSON.parse()将值转化为json对象。