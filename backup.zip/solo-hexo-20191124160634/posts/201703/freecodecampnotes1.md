title: freecodecamp-notes-1
date: '2017-03-25 04:07:36'
updated: '2017-03-25 04:07:36'
tags: [blog]
permalink: /articles/2017/03/25/1572681383620.html
---
## 标签
    <h1>一级主标题</h1>
    <h2>二级副标题</h2>
    <h3>三级标题</h3>
    <h4>四级标题</h4>
    <h5>五级标题</h5>
    <h6>六级标题</h6>
    标题字体大小递减
    <p>段落标签</p>
    
    <img src="http://p1.bpimg.com/4851/4001143c71b75b0e.jpg"/></br>
    自闭和标签,src用于添加图片地址。</br>
    alt属性是图片无法加载时的替代文本，有助于引擎搜索。</br>
    <a href="#">anchor锚点元素，用于页面跳转及内部导航；#表示是固定链接</a></br>
    元素可以嵌套，比如将img标签嵌入a标签中使之成为链接。</br>
    
    <div>
    无序列表：
    <ul>
       <li></li>
       <li></li>
    </ul>
    有序列表：
    <ol>
       <li></li>
       <li></li>
    </ol>
    div（division）元素是其他元素的通用盛装容器；
    可以用css使它的子元素继承其css样式。
    </div>

    表单元素:</br>
    必填项属性required在Safari浏览器中不起作用。
    多选一的情况用单选按钮，它只是input输入框的一种类型；
    且每一个都应该嵌入自己的label标签中，相关联的按钮name属性应该相同。
    多选多的情况用复选框，其与单选框相似；checked属性可以设置默认框。
    <form action="表单提交服务器地址">
    <label><input type="text" placeholder="占位符" required/>文本框</label>
    <label><button type="submit">提交按钮</button></label>
    <label><input type="radio" name="same_r" checked>单选框1</lable>
    <label><input type="radio" name="same_r">单选框2</lable>
    <label><input type="checkbox" name="same_cb" checked>复选框1</lable>
    <label><input type="checkbox" name="same_cb">复选框2</lable>
    </form>
<!--more-->
## 样式
通过元素的style可以改变元素内容设置；样式多达上千，常用的仅几十个。（内联样式）</br>
层叠样式表css更易维护<style></style></br>
css内可应用选择器更改元素样式：
元素选择器，
类选择器，（一个元素可以有多个用空格隔开的class;例：.class;）
ID选择器，（据说在使用jQuery时有很多好处;具有唯一性；例：#ID；>

字号由font-size属性控制；font-family属性用于设置元素字体；可以用link自闭和标签引入需要的字体；有几种默认字体所有浏览器都可用，当某种字体不可用时，你可以让浏览器自动降级到另一种字体。</br>
width设置宽度；height用于设置高度；</br>
css边框属性有border-style，border-color，border-width，border-height，border-radius边框半径将边框变圆，值可以是像素值px及百分比；

background-color属性用于设置元素背景颜色。

## 其他
`<!--注释可以让代码不起作用,提高代码可读性-->`</br>
占位符用于占位，无实意。


感悟：仅仅单独的学前端，停留在初级水平，职业防御纵深是不够的。